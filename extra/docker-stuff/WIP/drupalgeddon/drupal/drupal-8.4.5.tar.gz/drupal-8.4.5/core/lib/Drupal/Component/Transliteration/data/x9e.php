<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'chu', 'luo', 'xi', 'yi', 'ji', 'ze', 'yu', 'zhan', 'ye', 'yang', 'pi', 'ning', 'hu', 'mi', 'ying', 'meng',
  0x10 => 'di', 'yue', 'yu', 'lei', 'bao', 'lu', 'he', 'long', 'shuang', 'yue', 'ying', 'guan', 'qu', 'li', 'luan', 'niao',
  0x20 => 'jiu', 'ji', 'yuan', 'ming', 'shi', 'ou', 'ya', 'cang', 'bao', 'zhen', 'gu', 'dong', 'lu', 'ya', 'xiao', 'yang',
  0x30 => 'ling', 'chi', 'qu', 'yuan', 'xue', 'tuo', 'si', 'zhi', 'er', 'gua', 'xiu', 'heng', 'zhou', 'ge', 'luan', 'hong',
  0x40 => 'wu', 'bo', 'li', 'juan', 'gu', 'e', 'yu', 'xian', 'ti', 'wu', 'que', 'miao', 'an', 'kun', 'bei', 'peng',
  0x50 => 'qian', 'chun', 'geng', 'yuan', 'su', 'hu', 'he', 'e', 'gu', 'qiu', 'ci', 'mei', 'wu', 'yi', 'yao', 'weng',
  0x60 => 'liu', 'ji', 'yi', 'jian', 'he', 'yi', 'ying', 'zhe', 'liu', 'liao', 'jiao', 'jiu', 'yu', 'lu', 'huan', 'zhan',
  0x70 => 'ying', 'hu', 'meng', 'guan', 'shuang', 'lu', 'jin', 'ling', 'jian', 'xian', 'cuo', 'jian', 'jian', 'yan', 'cuo', 'lu',
  0x80 => 'you', 'cu', 'ji', 'pao', 'cu', 'pao', 'zhu', 'jun', 'zhu', 'jian', 'mi', 'mi', 'yu', 'liu', 'chen', 'jun',
  0x90 => 'lin', 'ni', 'qi', 'lu', 'jiu', 'jun', 'jing', 'li', 'xiang', 'xian', 'jia', 'mi', 'li', 'she', 'zhang', 'lin',
  0xA0 => 'jing', 'qi', 'ling', 'yan', 'cu', 'mai', 'mai', 'he', 'chao', 'fu', 'mian', 'mian', 'fu', 'pao', 'qu', 'qu',
  0xB0 => 'mou', 'fu', 'xian', 'lai', 'qu', 'mian', 'chi', 'feng', 'fu', 'qu', 'mian', 'ma', 'me', 'mo', 'hui', 'mo',
  0xC0 => 'zou', 'nun', 'fen', 'huang', 'huang', 'jin', 'guang', 'tian', 'tou', 'hong', 'hua', 'kuang', 'hong', 'shu', 'li', 'nian',
  0xD0 => 'chi', 'hei', 'hei', 'yi', 'qian', 'dan', 'xi', 'tun', 'mo', 'mo', 'qian', 'dai', 'chu', 'you', 'dian', 'yi',
  0xE0 => 'xia', 'yan', 'qu', 'mei', 'yan', 'qing', 'yue', 'li', 'dang', 'du', 'can', 'yan', 'yan', 'yan', 'dan', 'an',
  0xF0 => 'zhen', 'dai', 'can', 'yi', 'mei', 'zhan', 'yan', 'du', 'lu', 'zhi', 'fen', 'fu', 'fu', 'mian', 'mian', 'yuan',
];
